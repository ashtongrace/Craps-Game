package gui;

import java.io.File;
import java.io.IOException;

import javax.sound.sampled.*;
import javafx.animation.AnimationTimer;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.event.ActionEvent; //will be defined in the try catch method
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import model.Game;
import model.FileBot;
import model.HighScore;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;


@SuppressWarnings("unused") 
public class CrapsGameController {
	
	private Stage stage;
	private Scene scene;
	private Parent root; 
	
	//Game 
	Game craps; 
	
	int turn = 1;
	int players = 2;
	boolean newRound = false;
	boolean pass = true;
	
	Roller clock;
	
	//FileWriter
	
	FileBot fileBot;
	
	//GUI controls
	@FXML
	private BorderPane borderPane;
	
	@FXML
	private Label gameLabel;
	
	@FXML
	private VBox vBoxLeft;
	
	@FXML
	private VBox vBoxRight;
	
	@FXML 
	private HBox hBoxCenter;
	
	@FXML
	private HBox hBoxBottom;
	
	@FXML
	private ImageView leftImageView; //left die
	
	@FXML
	private ImageView rightImageView; //right die
	
	@FXML
	private Label playerMoneyLabel; //reads 'player score'
	
	@FXML
	private TextField playerMoneyTextField; //shows player score underneath the associated label 
	
	@FXML
	private Label lastRollLabel;

	@FXML
	private TextField lastRollTextField;

	@FXML 
	private Label cpuMoneyLabel;
	
	@FXML
	private TextField cpuMoneyTextField;
	
	@FXML
	private Label cpuLastRollLabel;
	
	@FXML
	private TextField cpuLastRollTextField;
	
	@FXML
	private Button resetButton; //associated action resetButtonPressed
	
	@FXML
	private Button diceRollButton; //associated action rollDiceButtonPressed
	
	@FXML
	private Label currentRollLabel;
	
	@FXML
	private TextField currentRollTextField;
	
	@FXML
	private TextArea gameMessageBox; //shows messages for the user, similar to a console
	
	@FXML
	private Pane pane;
	
	@FXML
	private TextField bettingField; //the field where a user may input their bet amount
	
	@FXML
	private Button betButton1; //pass bet button
	
	@FXML
	private Button betButton11; //no pass bet button
	
	@FXML
	private TextField playerNameField; //the field, at the top of the game, that reads the name (next to save/load)
	
	@FXML
	private Button saveButton; //saves the game
	
	@FXML
	private Button exitButton;
	
	@FXML
	private Button gameTypeButton;
	
	@FXML
	private Button rulesB;
	
    @FXML
    private TextField nameTextField; //the name text field on playerinfo.fxml
    
    @FXML
    private Label playerName; //the main instance of the player one name
    
    @FXML
    private Label leaderboardTitle;
    
    @FXML
    private Label leader1;
    
    @FXML
    private Label leader2;
    
    @FXML
    private Label leader3;
    
    @FXML
    private Label leader4;
    
    @FXML
    private Label leader5;
    
    @FXML
    private Button startButton;
    
    private String name;
    
    @FXML
    private Button addNameButton;
    
    
    

    
    /*@FXML
    public void switchToGameRules1(){
    	Parent root = FXMLLoader.load(getClass().getResource("test.fxml"));
		Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
		GameRulesController gamerulescontroller = new GameRulesController(this);
		gamerulescontroller.showStage();
	}*/
    @FXML
    public void switchToTitleScreen(ActionEvent event) throws IOException{
		Parent root = FXMLLoader.load(getClass().getResource("TitleScreen.fxml"));
		Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}

   

	//called so it starts craps game scene, 
    //USED TO BE STARTGAME FUNCTION
    
		@FXML
		public void initialize(ActionEvent event) {			
			
			
			craps = new Game();
			clock = new Roller();
			fileBot = new FileBot();
			
			setDieImage(craps.getdie1().getTop()); 
			setDieImage2(craps.getdie2().getTop()); 
			updateViews();
			updateLeaderboard();
			gameMessageBox.setText("Welcome! You both begin with 10 points. \nEnter your name at the top and add it! Then, place a bet above!");
			playerMoneyTextField.setText("10");
			cpuMoneyTextField.setText("10");
			cpuLastRollTextField.setText("0"); 
			lastRollTextField.setText("0");
			currentRollTextField.setText("0");
			
			
		}
		
	 
	
	
	//function for roll button being pressed
	@FXML
	private void rollDiceButtonPressed(ActionEvent event) {
		try {
			
			if(players == 2) {	
				//Ensures the correct player is playing
				if(turn == 1) {
					craps.setCurrent(craps.getp1());
				}
				else if (turn == 2) {
					craps.setCurrent(craps.getp2());
				}
				
				//Checks to make sure round is not already over
				if (!newRound) {
					
					//Checks if current bet is valid
					if(craps.getCurrent().getBet() <= 0 || craps.getCurrent().getBet() > craps.getCurrent().getTotalScore()) {
						
						throw new ArithmeticException("Invalid Bet!");
					}
				
					//this is the code that controls the dice roll noise!
					try {
						AudioInputStream ais = AudioSystem.getAudioInputStream(new File("src/gui/dice.wav"));
						Clip test = AudioSystem.getClip();
						
						test.open(ais);
						test.start();
						
						while(!test.isRunning())
							Thread.sleep(5);
						while(test.isRunning())
							Thread.sleep(5);
						
						test.close();
					} catch (Exception ex) {
						ex.printStackTrace();
						
						
					}
			
					//Animates dice and controls roll logic
					clock.start();
				}
			}
			else if(players == 1) {
				
				turn = 1;
				craps.setCurrent(craps.getp1());
				
				if (!newRound) {
					//Checks if current bet is valid
					if(craps.getCurrent().getBet() <= 0 || craps.getCurrent().getBet() > craps.getCurrent().getTotalScore()) {
						
						throw new ArithmeticException("Invalid Bet!");
					}
				}
				
				//this is the code that controls the dice roll noise!
				try {
					AudioInputStream ais = AudioSystem.getAudioInputStream(new File("src/gui/dice.wav"));
					Clip test = AudioSystem.getClip();
					
					test.open(ais);
					test.start();
					
					while(!test.isRunning())
						Thread.sleep(5);
					while(test.isRunning())
						Thread.sleep(5);
					
					test.close();
				} catch (Exception ex) {
					ex.printStackTrace();
					
					
				}
		
				//Animates dice and controls roll logic
				clock.start();
			}
		}
		catch (Exception e){
			//Tells player if a valid bet needs to be placed
			gameMessageBox.setText("Please place a valid bet!");
			pane.setBackground(new Background(new BackgroundFill(Color.rgb(140,22,48), null, null)));
		}
	}
	
	//Function for setting player pass bet
	@FXML
	private void betButtonPressed(ActionEvent event) {
		try {
			
			//Checks to make sure round isn't over
			if (!newRound) {
				
				//sets bet to "pass"
				pass = true;
				
				//checks if bet is within bounds of player's money pool
				if(Integer.parseInt(bettingField.getText()) > craps.getCurrent().getTotalScore() || Integer.parseInt(bettingField.getText()) < 0) {
					
					throw new ArithmeticException("Invalid Bet");
				}
				else {
					pane.setBackground(null);
				}
				
				//Sets bet to correct player
				if(turn == 1) {
					craps.getp1().setBet(Integer.parseInt(bettingField.getText()));
					gameMessageBox.setText("You have bet " + craps.getp1().getBet());			
				}
				if(turn == 2) {
					craps.getp2().setBet(Integer.parseInt(bettingField.getText()));
					gameMessageBox.setText("You have bet " + craps.getp2().getBet());			
				}
			}
		}
		catch (Exception e) {
			gameMessageBox.setText("Bet is invalid, please try again.");
		}
	}
	
	//Function for setting player no pass bet
	@FXML
	private void betButtonNoPressed(ActionEvent event) {
		try {
			//checks to make sure round isn't over
			if (!newRound) {
				
				//sets bet to "no pass"
				pass = false;
				
				//checks if bet is within bounds of player's money pool
				if(Integer.parseInt(bettingField.getText()) > craps.getCurrent().getTotalScore() || Integer.parseInt(bettingField.getText()) < 0) {
					
					throw new ArithmeticException("Invalid Bet");
				}
				else {
					pane.setBackground(null);
				}
				
				//Sets bet to correct player
				if(turn == 1) {
					craps.getp1().setBet(Integer.parseInt(bettingField.getText()));
					gameMessageBox.setText("You have bet " + craps.getp1().getBet());			
				}
				if(turn == 2) {
					craps.getp2().setBet(Integer.parseInt(bettingField.getText()));
					gameMessageBox.setText("You have bet " + craps.getp2().getBet());			
				}
			}
		}
		catch (Exception e) {
			gameMessageBox.setText("Bet is invalid, please try again.");
		}
	}

	//Logic for animation timer to call when a player presses the Roll button
	@FXML
	private void rollButton() {
		try {
			
			
			//One of three sets to ensure the correct player is playing
			if(turn == 1) {
				craps.setCurrent(craps.getp1());
			}
			else if (turn == 2) {
				craps.setCurrent(craps.getp2());
			}
			
			//Calls roll to randomize TwoDice object and set current roll to result
			roll();
			currentRollTextField.setText("" + craps.getDice().getTotal());
			
			//Ensures correct player is highlighted
			updateViews();
			
			//Sets current player turn score to value rolled
			craps.currentSetDice();
			
			//Gate to differentiate players
			if(turn == 1) {
				
				//Sets current player turn score to value rolled
				craps.getp1().setTurnScore(craps.getDice().getTotal());
				
				//One of three sets to ensure the correct player is playing
				craps.setCurrent(craps.getp1());
				
				//Checks if it's the player's first roll
				if(craps.getRoll() == 1) {
					
					//Sets text field to show what the player rolled on their first roll
					lastRollTextField.setText("" + craps.getDice().getTotal());
					
					
					//Checks if player rolled a winning number on the first roll
					if(craps.getDice().getTotal() == 7 || craps.getDice().getTotal() == 11) {
						
						if(players == 2) {
							//Calculates pay out according to bet made
							if (pass) {
								craps.currentAddScore(turn);
								gameMessageBox.setText("You rolled a " + craps.getp1().getFirstRoll() + " on your first roll!\nYou win the turn because you bet pass!");
							}
							else {
								craps.currentLoseScore(turn);
								gameMessageBox.setText("You rolled a " + craps.getp1().getFirstRoll() + " on your first roll!\nYou lose the turn because you bet no pass!");
							}
							
							//Switches to opposite players turn and shows current scores
							craps.turnSwitch();
							updateScores();
							turn = 2;
						}
						else if(players == 1) {
							//Calculates pay out according to bet made
							if (pass) {
								craps.p1AddScore();
								gameMessageBox.setText("You rolled a " + craps.getp1().getFirstRoll() + " on your first roll!\nYou win the turn because you bet pass!");
							}
							else {
								craps.p1LoseScore();
								gameMessageBox.setText("You rolled a " + craps.getp1().getFirstRoll() + " on your first roll!\nYou lose the turn because you bet no pass!");
							}
							
							//updates the players score;
							updateScores();
						}
					}
					//Checks if player rolled a losing number on the first roll
					else if(craps.getDice().getTotal() == 2 || craps.getDice().getTotal() == 3 || craps.getDice().getTotal() == 12) {
						
						if(players == 2) {
							//Calculates pay out according to bet made
							if (pass) {
								craps.currentLoseScore(turn);
								gameMessageBox.setText("You rolled a " + craps.getp1().getFirstRoll() + " on your first roll!\nYou lose the turn because you bet pass!");
							}
							else {
								craps.currentAddScore(turn);
								gameMessageBox.setText("You rolled a " + craps.getp1().getFirstRoll() + " on your first roll!\nYou win the turn because you bet no pass!");
							}
							
							//Switches to opposite players turn and shows current scores
							craps.turnSwitch();
							updateScores();
							turn = 2;
						}
						else if(players == 1) {
							
							//Calculates pay out according to bet made
							if (pass) {
								craps.p1LoseScore();
								gameMessageBox.setText("You rolled a " + craps.getp1().getFirstRoll() + " on your first roll!\nYou lose the turn because you bet pass!");
							}
							else {
								craps.p1AddScore();
								gameMessageBox.setText("You rolled a " + craps.getp1().getFirstRoll() + " on your first roll!\nYou win the turn because you bet no pass!");
							}
							
							updateScores();
						}
					}
					//Saves roll as first roll for player and moves on to later rolls
					else {
						craps.getp1().setFirstRoll(craps.getDice().getTotal());
						craps.setRoll(2);
						gameMessageBox.setText("You rolled a " + craps.getp1().getFirstRoll() + "!\nTry to match this on your next roll, but watch out for 7s!");
					}
				}
				//Checks if player won on a later roll
				else if(craps.getp1().getFirstRoll() == craps.getDice().getTotal()) {
					
					if(players == 1) {
						//Calculates payout according to bet made
						if (pass) {
							craps.currentAddScore(turn);
							gameMessageBox.setText("You rolled a " + craps.getDice().getTotal() + " and matched your first roll!\nYou win because you bet pass!");
						}
						else {
							craps.currentLoseScore(turn);
							gameMessageBox.setText("You rolled a " + craps.getDice().getTotal() + " and matched your first roll!\nYou lose because you bet no pass!");
						}
						
						//Switches to opposite players turn, shows current scores, and goes back to first roll
						craps.turnSwitch();
						updateScores();
						turn = 2;
						craps.setRoll(1);
					}
					else if(players == 2) {
						
						if (pass) {
							craps.p1AddScore();
							gameMessageBox.setText("You rolled a " + craps.getDice().getTotal() + " and matched your first roll!\nYou win because you bet pass!");
						}
						else {
							craps.p1LoseScore();
							gameMessageBox.setText("You rolled a " + craps.getDice().getTotal() + " and matched your first roll!\nYou lose because you bet no pass!");
						}
						
						updateScores();
						craps.setRoll(1);
					}
				}
				//Checks if player lost on a later roll
				else if (craps.getDice().getTotal() == 7) {
					
					if(players == 2) {
						//Calculates pay out according to bet made
						if (pass) {
							craps.currentLoseScore(turn);
							gameMessageBox.setText("You rolled a " + craps.getDice().getTotal() + " on a later roll!\nYou lose the turn because you bet pass!");
						}
						else {
							craps.currentAddScore(turn);
							gameMessageBox.setText("You rolled a " + craps.getDice().getTotal() + " on a later roll!\nYou win the turn because you bet no pass!");
						}
						
						//Switches to opposite players turn, shows current scores, and goes back to first roll
						craps.turnSwitch();
						updateScores();
						turn = 2;
						craps.setRoll(1);
					}
					else if(players == 1) {
						
						if (pass) {
							craps.p1LoseScore();
							gameMessageBox.setText("You rolled a " + craps.getDice().getTotal() + " on a later roll!\nYou lose the turn because you bet pass!");
						}
						else {
							craps.p1AddScore();
							gameMessageBox.setText("You rolled a " + craps.getDice().getTotal() + " on a later roll!\nYou win the turn because you bet no pass!");
						}
						
						updateScores();
						craps.setRoll(1);
					}
				}
				else {
					gameMessageBox.setText("You rolled a " + craps.getDice().getTotal() + ". This is not a " + craps.getp1().getFirstRoll() + " or a 7, so play continues.\nPlease roll again!");				
				}
			}
			//Gate to differentiate players
			else if(turn == 2) {
				
				//Sets current player turn score to value rolled
				craps.getp2().setTurnScore(craps.getDice().getTotal());
				
				//One of three sets to ensure the correct player is playing
				craps.setCurrent(craps.getp2());
				
				//Checks if it's the player's first roll
				if(craps.getRoll() == 1) {
					
					//Sets text field to show what the player rolled on their first roll
					cpuLastRollTextField.setText("" + craps.getDice().getTotal());
					
					//Checks if player rolled a winning number on the first roll
					if(craps.getDice().getTotal() == 7 || craps.getDice().getTotal() == 11) {
						
						//Calculates pay out according to bet made
						if (pass) {
							craps.currentAddScore(turn);
							gameMessageBox.setText("You rolled a " + craps.getp2().getFirstRoll() + " on your first roll!\nYou win the turn because you bet pass!");
						}
						else {
							craps.currentLoseScore(turn);
							gameMessageBox.setText("You rolled a " + craps.getp2().getFirstRoll() + " on your first roll!\nYou lose the turn because you bet no pass!");
						}
						
						//Switches to opposite players turn and shows current scores
						craps.turnSwitch();
						updateScores();
						turn = 1;
					}
					//Checks if player rolled a losing number on the first roll
					else if(craps.getDice().getTotal() == 2 || craps.getDice().getTotal() == 3 || craps.getDice().getTotal() == 12) {
						
						//Calculates pay out according to bet made
						if (pass) {
							craps.currentLoseScore(turn);
							gameMessageBox.setText("You rolled a " + craps.getp2().getFirstRoll() + " on your first roll!\nYou lose the turn because you bet pass!");
						}
						else {
							craps.currentAddScore(turn);
							gameMessageBox.setText("You rolled a " + craps.getp2().getFirstRoll() + " on your first roll!\nYou win the turn because you bet no pass!");
						}
						
						//Switches to opposite players turn and shows current scores
						craps.turnSwitch();
						updateScores();
						turn = 1;
					}
					//Saves roll as first roll for player and moves on to later rolls
					else {
						craps.getp2().setFirstRoll(craps.getDice().getTotal());
						craps.setRoll(2);
						gameMessageBox.setText("You rolled a " + craps.getp2().getFirstRoll() + "!\nTry to match this on your next roll, but watch out for 7s!");
					}
				}
				//Checks if player won on a later roll
				else if(craps.getp2().getFirstRoll() == craps.getDice().getTotal()) {
					
					//Calculates pay out according to bet made
					if (pass) {
						craps.currentAddScore(turn);
						gameMessageBox.setText("You rolled a " + craps.getDice().getTotal() + " and matched your first roll!\nYou win because you bet pass!");
					}
					else {
						craps.currentLoseScore(turn);
						gameMessageBox.setText("You rolled a " + craps.getDice().getTotal() + " and matched your first roll!\nYou lose because you bet no pass!");
					}
					
					//Switches to opposite players turn, shows current scores, and goes back to first roll
					craps.turnSwitch();
					updateScores();
					turn = 1;
					craps.setRoll(1);
				}
				//Checks if player lost on a later roll
				else if (craps.getDice().getTotal() == 7) {
					
					//Calculates pay out according to bet made
					if (pass) {
						craps.currentLoseScore(turn);
						gameMessageBox.setText("You rolled a " + craps.getDice().getTotal() + " on a later roll!\nYou lose the turn because you bet pass!");
					}
					else {
						craps.currentAddScore(turn);
						gameMessageBox.setText("You rolled a " + craps.getDice().getTotal() + " on a later roll!\nYou win the turn because you bet no pass!");
					}
					
					//Switches to opposite players turn, shows current scores, and goes back to first roll
					craps.turnSwitch();
					updateScores();
					turn = 2;
					craps.setRoll(1);
				}
				else {
					gameMessageBox.setText("You rolled a " + craps.getDice().getTotal() + ". This is not a " + craps.getp1().getFirstRoll() + " or a 7, so play continues.\nPlease roll again!");				
				}
			}
			
			//sets players high score if it is higher
			craps.getp1().updateHighScore();
			
			if(players == 1){
				vBoxRight.setBackground(new Background(new BackgroundFill(Color.rgb(20,20,20), null, null)));
			}
			
			//Checks if either player has won
			if (craps.getp1().getTotalScore() <= 0) {
				gameMessageBox.setText(gameMessageBox.getText() + "\nCPU has won! Please reset!");
				newRound = true;
			}
			if (craps.getp2().getTotalScore() <= 0) {
				gameMessageBox.setText(gameMessageBox.getText() + "\nPlayer has won! Please save your name to add your score to the leaderboard and reset!");
				newRound = true;
			}
			
			
	}
		
	catch(Exception e) {
		
		}
	}
	
	//Set craps Game object back to initial game state
	@FXML
	private void resetButtonPressed(ActionEvent event) {
	
		craps.getp1().resetTurnScore();
		craps.getp1().resetTotalScore();
		craps.getp2().resetTurnScore();
		craps.getp2().resetTotalScore();
		craps.getp1().resetBet();
		craps.getp2().resetBet();
		craps.getDice().getTotal();
		craps.setRoll(1);
		craps.setCurrent(craps.getp1());
		gameMessageBox.setText("Welcome! You both begin with 10 points. \nEnter your name at the top and add it! Then, place a bet above!");
		pane.setBackground(null);
		vBoxLeft.setBackground(new Background(new BackgroundFill(Color.PINK, null, null)));
		vBoxRight.setBackground(null); 
		if(players == 1) {
			
			vBoxRight.setBackground(new Background(new BackgroundFill(Color.rgb(20,20,20), null, null)));
		}
		newRound = false;
		
		//set the cpuMoneyTextField to zero
		cpuMoneyTextField.setText("10");
		//set the cpuLastRollTextField to zero
		cpuLastRollTextField.setText("0");
		//set the playerMoneyTextField to zero
		playerMoneyTextField.setText("10");
		//set the playerLastRollTextField
		lastRollTextField.setText("0");
		//set the playerCurrentRollTextField
		currentRollTextField.setText("0");
		
		updateLeaderboard();
	
	
} 
	
	//action event for saving the current game under a player's profile
	@FXML
	private void saveButtonPressed(ActionEvent event) {
		
		craps.setName(playerNameField.getText());
		HighScore save = new HighScore(craps.getName(),craps.getp1().getHighScore());
		fileBot.savePlayerProfile(save);
		updateLeaderboard();
	}
	
		private void updateLeaderboard() {
			
			List<HighScore> leaders = fileBot.getHighScores5();
			
			leader1.setText(leaders.get(0).getName() + ": " + leaders.get(0).getScore());
			if(leaders.size() > 1) {
				
				leader2.setText(leaders.get(1).getName() + ": " + leaders.get(1).getScore());
				
				if(leaders.size() > 2) {
					
					leader3.setText(leaders.get(2).getName() + ": " + leaders.get(2).getScore());
					
					if(leaders.size() > 3) {
						
						leader4.setText(leaders.get(3).getName() + ": " + leaders.get(3).getScore());
						
						if(leaders.size() > 4) {
						    leader5.setText(leaders.get(4).getName() + ": " + leaders.get(4).getScore());
						}
					}
				}
			}
			
			
		}
	
	@FXML
		private void addButtonPressed(ActionEvent event) {
		playerName.setText(playerNameField.getText());
	}
	
	//sets the background color for the vboxes to green depending on who's turn it is
	public void updateViews() {
		if(craps.p1Turn()) {
			//getFill, getInsets, getRadii - so this fills and ignores insets and radii
			vBoxLeft.setBackground(new Background(new BackgroundFill(Color.PINK, null, null)));
			vBoxRight.setBackground(null);
		} else { 
			vBoxRight.setBackground(new Background(new BackgroundFill(Color.PINK, null, null)));
			vBoxLeft.setBackground(null);
		}
		
	}
	
	
	//Sets image of left die
	public void setDieImage(int top) { 
		File f = new File("src/resources/result" + top + ".png");
		//String imagePath = String.format("../resources/result%d.png", top);
		leftImageView.setImage(new Image(f.toURI().toString()));
	}
	
	//Sets image of right die
	public void setDieImage2(int top) {
		File f = new File("src/resources/result" + top + ".png");
		rightImageView.setImage(new Image(f.toURI().toString()));
	}
	
	//roll and call set images to change images to match with top
	public void roll() {
		craps.getDice().roll();
		setDieImage(craps.getDice().getTop());
		setDieImage2(craps.getDice().getTop2());
	}
	
	//method to set players score text fields to the correct values
	private void updateScores() {

		playerMoneyTextField.setText("" + craps.getp1().getTotalScore());
		cpuMoneyTextField.setText("" + craps.getp2().getTotalScore());
	}
	
	@FXML
	private void swapGameType(ActionEvent event) {
		
		resetButtonPressed(event);
		
		if(players == 1) {
			players = 2;
			gameTypeButton.setText("Switch to Singleplayer");
			vBoxRight.setBackground(null);
		}
		else if(players == 2) {
			players = 1;
			gameTypeButton.setText("Switch to Versus");
			vBoxRight.setBackground(new Background(new BackgroundFill(Color.rgb(20,20,20), null, null)));
		}
	}
	
	//Class for animating two dice rolling (also calls methods specific to this program for efficiency)
	private class Roller extends AnimationTimer{
		
		private long FRAMES_PER_SEC = 40L;
		private long INTERVAL = 1000000000L / FRAMES_PER_SEC;
		private int MAX_ROLLS = 12;
		
		private long last = 0;
		private int count = 0;
		
		@Override
		public void handle(long now) {
			if (now - last > INTERVAL) {
				setDieImage((int)(1 + craps.getDice().getSides() * Math.random()));
				setDieImage2((int)(1 + craps.getDice().getSides() * Math.random()));
				last = now;
				count++;
				if(count > MAX_ROLLS) {
					stop();
					count = 0;
					setDieImage(craps.getDice().getTop());
					setDieImage2(craps.getDice().getTop2());
					
					rollButton();
				
				}
			}
		}

	}
}

