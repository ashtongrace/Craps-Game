package gui;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import java.io.IOException;


@SuppressWarnings("unused")

public class SwitchingScenes {
    
	@FXML
	private Button rulesButton;
	
	@FXML
	private Label mainGameLabel;
	
	@FXML
	private Button playButton;
	
	@FXML
	private Label rulesLabel;
	
	@FXML
	private Button rulesBackButton;
	
	@FXML
	private TextArea rulesText;
	
	@FXML
	private Button NextButton;
	
	@FXML
	private TextField nameTextField;
	
	@FXML
	private Label enterNameLabel;
	
	@FXML
	private ImageView iconDie;
	
	@FXML 
	private ImageView blackBackground;
	
	 @FXML
	    public void switchToGameRules(ActionEvent event) throws IOException{
			Parent root = FXMLLoader.load(getClass().getResource("GameRules.fxml"));
			Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
		}

	    @FXML
		public void switchToPlayerInfo(ActionEvent event) throws IOException {
			Parent root = FXMLLoader.load(getClass().getResource("PlayerInfo.fxml"));
			Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
	    }    
	    
	    @FXML
	    public void switchToTitleScreen(ActionEvent event) throws IOException{
			Parent root = FXMLLoader.load(getClass().getResource("TitleScreen.fxml"));
			Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
		}

	  
	    /*Parent root = FXMLLoader.load(getClass().getResource("test.fxml"));
		Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
*/
	    @FXML
		public void switchToCrapsGame(ActionEvent event) throws IOException {
			Parent root = FXMLLoader.load(getClass().getResource("test.fxml"));
			Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
	    }    
	 
	 
	
}

