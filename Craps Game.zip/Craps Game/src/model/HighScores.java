package model;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;

public class HighScores {

	
	@XmlElement(name="highscore") 
	   private List<HighScore> highScores = new ArrayList<>();

	   public List<HighScore> getHighScores() {return highScores;}
}

