package model;

public class Game{
	
	//Variable initialization
	
	private die d1;
	private die d2;
	private twoDice dice;
	private Player p1;
	private Player p2;
	private Player current;
	private int roll;
	private boolean roundOver;
	private String name;
	
	
	//Constructor
	public Game() {
		d1 = new die(6, 1); //6 sides, 1 top
		d2 = new die(6, 1); //6 sides, 1 top
		dice = new twoDice(1, 6, 1); //6 sides, both dice are currently on 1
		p1 = new Player(); //new instance of player 1
		p2 = new Player(); //new instance of player 2
		current = p1; //current player defaults to 1
		roll = 1;
		roundOver = false;
		name = "demo";
	}
	
	//gets the amount for die 1
	public die getdie1() {
		return d1;
	}
	
	//gets the amount for die 2
	public die getdie2() {
		return d2;
	}
	
	//gets the dice object
	public twoDice getDice() {
		return dice;
	}
	
	//getter method for which player's turn it is 
	public Player getCurrent() {
		return current;
	}
	
	//return method for player one
	public Player getp1() {
		return p1;
	}
	
	//return method for player two
	public Player getp2() {
		return p2;
	}
	
	
	//returns what the roll the player is on
	public int getRoll() {
		return roll;
	}
	
	//returns whether or not the round is over
	public boolean getRoundOver() {
		return roundOver;
	}
	
	//sets whether or not the round is over
	public void setRoundOver(boolean boo) {
		roundOver = boo;
	}
	
	//return method for player one's turn
	public boolean p1Turn() {
		return current == p1;
	}
	
	//if it is player one's turn, switch to player two, otherwise switch to player one
	public void turnSwitch() {
		if(p1Turn()) {
			current = p2;
		} else { 
			current = p1;
		}
	}
	
	//Sets current to current player
	public void setCurrent(Player player) {
		current = player;
	}
	
	//Sets player 1's turn score to die roll
	public void p1SetDice() {
		p1.setTurnScore(dice.getTotal());
	}
	
	//Sets player 2's turn score to die roll
	public void p2SetDice() {
		p2.setTurnScore(dice.getTotal());
	}
	
	//sets current players turn score to die roll
	public void currentSetDice() {
		current.setTurnScore(dice.getTotal());
	}
	
	//adds 1 to player 1's score
	public void p1AddScore() {
		p1.setTotalScore(p1.getTotalScore() + p1.getBet());
	}
	
	//adds 2 to player 1's score
	public void p2AddScore() {
		p2.setTotalScore(p2.getTotalScore() + p2.getBet());
	}
	
	public void p1LoseScore() {
		p1.setTotalScore(p1.getTotalScore() - p1.getBet());
	}
	
	public void p2LoseScore() {
		p2.setTotalScore(p2.getTotalScore() - p2.getBet());
	}
	
	//Pays out bet amount for a win
	public void currentAddScore(int turn) {
		
		if (turn == 1) {
			p2.loseOut(p1.getBet());
			p1.payout();
		}
		if (turn == 2) {
			p1.loseOut(p2.getBet());
			p2.payout();
		}
		
		p1.resetBet();
		p2.resetBet();
	}
	
	//Pays out bet amount for a loss
	public void currentLoseScore(int turn) {
		
		if (turn == 2) {
			p2.loseOut();
			p1.payout(p2.getBet());
		}
		if (turn == 1) {
			p1.loseOut();
			p2.payout(p1.getBet());
		}
		
		p1.resetBet();
		p2.resetBet();
	}
	
	//Sets first roll of current player
	public void setCurrentFirst(int first) {
		current.setFirstRoll(first);
	}
	
	//adds 1 to roll number
	public void nextRoll() {
		roll++;
	}
	
	//sets roll number
	public void setRoll(int roll) {
		this.roll = roll;
	}
	
	//Sets profile name
	public void setName(String name) {
		this.name = name;
	}
	
	//Returns profile name
	public String getName() {
		return name;
	}
	
	//Prints game data (mainly for testing file writing)
	public void printGame() {
		System.out.println();
		System.out.println(p1.getTotalScore());
		System.out.println(p2.getTotalScore());
		System.out.println(getRoll());
		System.out.println();
	}
}
