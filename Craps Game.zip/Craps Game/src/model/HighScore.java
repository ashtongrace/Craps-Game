package model;

public class HighScore {

	private int score;
	private String name;
	
	public HighScore(String name, int score) {
		
		this.name = name;
		this.score = score;
	}
	
	public HighScore() {
	
		this("", 0);
	}
	
	public int getScore() {
		
		return score;
	}
	
	public String getName() {
		
		return name;
	}
	
	public void setScore(int score) {
		
		this.score = score;
	}
	
	public void setName(String name) {
		
		this.name = name;
	}
}

