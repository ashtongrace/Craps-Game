package model;

//Class for a single die
public class die{
	
	//variables for the constructor
	private int top;
	private int sides;
	
	//Constructor
	public die(int top, int sides) {
		this.top = top;
		this.sides = sides;
	}
	
	public die() {
		sides = 6; 
		top = 0;
	}
	

	//setters and getters
	public void setTop(int top) {
		if (top > 0 && top <= sides) {
			this.top = top;
		}
	}
	
	public void setSides(int sides) {

		this.sides = sides;
		if (top > sides) {
			top = sides;
		}
	}
	
	public int getTop() {
		return top;
	}
	
	public int getSides() {
		return sides;
	}
	
	//sets top to a random "rolled" integer between 0 and sides
	
	public void roll() {
		top = 1 + (int)(Math.random() * sides);
	}
	
	//Main method for testing
	public static void main(String[] args) {
		die d = new die(1, 6);
		System.out.println(d.getTop());
		for (int i = 0; i < 10; i++) {
			d.roll();
			System.out.println(i + ": " + d.getTop());
			
		}
		
	}

}
